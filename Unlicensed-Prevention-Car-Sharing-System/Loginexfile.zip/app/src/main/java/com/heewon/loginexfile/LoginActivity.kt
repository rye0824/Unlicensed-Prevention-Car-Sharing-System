package com.heewon.loginexfile


import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Response
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject

class LoginActivity : AppCompatActivity() {
    private var et_ID: EditText? = null
    private var et_PASS: EditText? = null
    private var btn_login: Button? = null
    private var btn_Register: Button? = null
    override fun onCreate(savedlnstanceState: Bundle?) {
        super.onCreate(savedlnstanceState)
        setContentView(R.layout.activity_login)
        et_ID = findViewById(R.id.et_ID)
        et_PASS = findViewById(R.id.et_PASS)
        btn_login = findViewById(R.id.btn_login)
        btn_Register = findViewById(R.id.btn_Register)

        btn_Register?.setOnClickListener(View.OnClickListener {
            val intent = Intent(this@LoginActivity, RegisterActivity::class.java)
            startActivity(intent)
        })
        btn_login?.setOnClickListener(View.OnClickListener {
            val userID = et_ID?.getText().toString()
            val userPASS = et_PASS?.getText().toString()
            val responseListener: Response.Listener<String> =
                Response.Listener { response ->
                    try {
                        val jsonObject = JSONObject(response)
                        val success = jsonObject.getBoolean("success")
                        if (success) { //로그인에 성공한 경우
                            val userID = jsonObject.getString("userID")
                            val userPASS = jsonObject.getString("userPassword")
                            Toast.makeText(applicationContext, "로그인에 성공하였습니다.", Toast.LENGTH_SHORT)
                                .show()
                            val intent = Intent(this@LoginActivity, MainActivity::class.java)
                            intent.putExtra("userID", userID)
                            intent.putExtra("userPASS", userPASS)
                            startActivity(intent)
                        } else { //로그인에 실패한 경우
                            Toast.makeText(applicationContext, "로그인에 실패하였습니다.", Toast.LENGTH_SHORT)
                                .show()
                            return@Listener
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            val loginRequest = LoginRequest(userID, userPASS, responseListener)
            val queue = Volley.newRequestQueue(this@LoginActivity)
            queue.add(loginRequest)
        })
    }
}